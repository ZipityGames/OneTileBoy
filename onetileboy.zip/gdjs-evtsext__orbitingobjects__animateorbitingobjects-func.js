
if (typeof gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects !== "undefined") {
  gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects = {};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex2 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex4 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachObjects2 = [];

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachObjects4 = [];

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachObjects5 = [];

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary2 = null;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary4 = null;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary5 = null;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTotalCount2 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTotalCount4 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTotalCount5 = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.stopDoWhile5 = false;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects7= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects2= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects7= [];

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.conditionTrue_0 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.conditionTrue_1 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition2IsTrue_1 = {val:false};


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects3Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects3Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3);

gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects3Objects, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].getVariables().get("LinkedObjectQuantity")).setNumber(gdjs.evtTools.object.pickedObjectsCount(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects3Objects));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects, (( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length === 0 ) ? 0 :gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0].getX()), (( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length === 0 ) ? 0 :gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0].getY()), (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("OrbitLayer") : ""));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[0] : null), (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0] : null));
}{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].setZOrder((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitZvalue")) || 0 : 0));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[i].getVariables().get("LinkedObjectQuantity")).setNumber(gdjs.evtTools.object.pickedObjectsCount(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects5Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].getVariables().get("OrbitOrder")).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0].getVariables()).get("OrbitingObjects").getChild("OrderCounter"))));
}
}}

}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[i].getVariables().get("OrbitingObjects").getChild("OrderCounter")).add(1);
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].setAngle((gdjs.RuntimeObject.getVariableNumber(((gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0].getVariables()).get("OrbitingObjects").getChild("RotationAngle"))));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.stopDoWhile5 = false;
do {gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5);

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[i].getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[i].getVariables().get("LinkedObjectQuantity")) < (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0) ) {
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = true;
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[k] = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length = k;}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {
if (true) {

{ //Subevents: 
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList1(runtimeScene, eventsFunctionContext);} //Subevents end.
}
} else gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.stopDoWhile5 = true; 
} while ( !gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.stopDoWhile5 );

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4[i].getVariables().get("OrbitingObjects").getChild("OrderCounter")).setNumber(1);
}
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4);

for(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5 = 0;gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5 < gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4.length;++gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5) {
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5);

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length = 0;


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary5 = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4[gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.push(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary5);
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects5Objects, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList2(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3);
{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].getVariables().get("OrbitAngle")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].getVariables().get("OrbitOrder"))) * (360 / (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0)) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("StartingOffset")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3);


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].getVariables().get("LinkedObjectQuantity")) < (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0) ) {
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = true;
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[k] = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length = k;}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6);

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6);


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition1IsTrue_0.val = false;
{
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects6Objects, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length;i<l;++i) {
    if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].getVariables().get("OrbitOrder")) > (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0) ) {
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition1IsTrue_0.val = true;
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[k] = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i];
        ++k;
    }
}
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length = k;}}
if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition1IsTrue_0.val) {
/* Reuse gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6 */
{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4);

for(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5 = 0;gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5 < gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4.length;++gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5) {
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length = 0;


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary5 = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4[gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex5];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.push(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary5);
if (true) {

{ //Subevents: 
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList5(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


{



}


{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.conditionTrue_1 = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.conditionTrue_1.val = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("ResetObjectsAfterDeletion") : false);
}
}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3);
{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].getVariables().get("OrbitAngle")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[i].getVariables().get("OrbitOrder"))) * (360 / (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0)) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("StartingOffset")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3);


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i].getVariables().get("LinkedObjectQuantity")) > (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitQuantity")) || 0 : 0) ) {
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = true;
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[k] = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length = k;}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects4Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariables().get("OrbitAngle")).add((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitSpeed")) || 0 : 0) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}}

}


{



}


{

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5);


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariables().get("OrbitAngle")) > 360 ) {
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = true;
        gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[k] = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length = k;}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5 */
{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariables().get("OrbitAngle")).setNumber(gdjs.evtTools.common.mod((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariables().get("OrbitAngle"))), 360));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5);

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].putAroundObject((gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[0] : null), (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("OrbitDistance")) || 0 : 0), (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].getVariables().get("OrbitAngle"))));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[i].rotate((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("ObjectRotationSpeed")) || 0 : 0), runtimeScene);
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5);

gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5);

{for(var i = 0, len = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length ;i < len;++i) {
    gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[i].returnVariable(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5[i].getVariables().get("OrbitingObjects").getChild("RotationAngle")).setNumber((( gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length === 0 ) ? 0 :gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5[0].getAngle()));
}
}}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3);

for(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex4 = 0;gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex4 < gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3.length;++gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex4) {
gdjs.copyArray(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4);

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4.length = 0;


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary4 = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3[gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex4];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4.push(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary4);
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_46evtsExt_95_95OrbitingObjects_95_95AnimateOrbitingObjects_46GDOrbitingObjectObjects4Objects, (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4.length !== 0 ? gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList8(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList0(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList4(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList7(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList9(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("CenterObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1);

for(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex2 = 0;gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex2 < gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1.length;++gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex2) {
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2.length = 0;


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary2 = gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1[gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachIndex2];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2.push(gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList10(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


};

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func = function(runtimeScene, CenterObject, OrbitingObject, OrbitQuantity, OrbitSpeed, OrbitDistance, ObjectRotationSpeed, OrbitLayer, OrbitZvalue, StartingOffset, ResetObjectsAfterDeletion, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"CenterObject": CenterObject
, "OrbitingObject": OrbitingObject
},
  _objectArraysMap: {
"CenterObject": gdjs.objectsListsToArray(CenterObject)
, "OrbitingObject": gdjs.objectsListsToArray(OrbitingObject)
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "OrbitQuantity") return OrbitQuantity;
if (argName === "OrbitSpeed") return OrbitSpeed;
if (argName === "OrbitDistance") return OrbitDistance;
if (argName === "ObjectRotationSpeed") return ObjectRotationSpeed;
if (argName === "OrbitLayer") return OrbitLayer;
if (argName === "OrbitZvalue") return OrbitZvalue;
if (argName === "StartingOffset") return StartingOffset;
if (argName === "ResetObjectsAfterDeletion") return ResetObjectsAfterDeletion;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects3.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects4.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects5.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects6.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects7.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects2.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects3.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects4.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects5.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects6.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects7.length = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList11(runtimeScene, eventsFunctionContext);
return;
}

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.registeredGdjsCallbacks = [];