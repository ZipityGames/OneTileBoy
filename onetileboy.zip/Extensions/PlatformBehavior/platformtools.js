var gdjs;(function(e){let a;(function(t){let n;(function(r){r.isOnPlatform=function(s,o,i,c){return e.evtTools.object.twoListsTest(e.PlatformRuntimeBehavior.isOnPlatformTest,s,i,c,o)}})(n=t.platform||(t.platform={}))})(a=e.evtTools||(e.evtTools={}))})(gdjs||(gdjs={}));
//# sourceMappingURL=platformtools.js.map
