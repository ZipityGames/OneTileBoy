gdjs.CreditCode = {};
gdjs.CreditCode.GDplayerObjects1= [];
gdjs.CreditCode.GDplayerObjects2= [];
gdjs.CreditCode.GDGuide2Objects1= [];
gdjs.CreditCode.GDGuide2Objects2= [];
gdjs.CreditCode.GDGuide22Objects1= [];
gdjs.CreditCode.GDGuide22Objects2= [];
gdjs.CreditCode.GDGuide23Objects1= [];
gdjs.CreditCode.GDGuide23Objects2= [];
gdjs.CreditCode.GDTitleObjects1= [];
gdjs.CreditCode.GDTitleObjects2= [];
gdjs.CreditCode.GDgrass1Objects1= [];
gdjs.CreditCode.GDgrass1Objects2= [];
gdjs.CreditCode.GDgrass2Objects1= [];
gdjs.CreditCode.GDgrass2Objects2= [];
gdjs.CreditCode.GDgrass3Objects1= [];
gdjs.CreditCode.GDgrass3Objects2= [];
gdjs.CreditCode.GDgrass4Objects1= [];
gdjs.CreditCode.GDgrass4Objects2= [];
gdjs.CreditCode.GDassetsObjects1= [];
gdjs.CreditCode.GDassetsObjects2= [];
gdjs.CreditCode.GDmusicObjects1= [];
gdjs.CreditCode.GDmusicObjects2= [];
gdjs.CreditCode.GDmusic2Objects1= [];
gdjs.CreditCode.GDmusic2Objects2= [];
gdjs.CreditCode.GDboneObjects1= [];
gdjs.CreditCode.GDboneObjects2= [];
gdjs.CreditCode.GDskullObjects1= [];
gdjs.CreditCode.GDskullObjects2= [];
gdjs.CreditCode.GDinfoObjects1= [];
gdjs.CreditCode.GDinfoObjects2= [];
gdjs.CreditCode.GDbackObjects1= [];
gdjs.CreditCode.GDbackObjects2= [];

gdjs.CreditCode.conditionTrue_0 = {val:false};
gdjs.CreditCode.condition0IsTrue_0 = {val:false};
gdjs.CreditCode.condition1IsTrue_0 = {val:false};
gdjs.CreditCode.condition2IsTrue_0 = {val:false};
gdjs.CreditCode.conditionTrue_1 = {val:false};
gdjs.CreditCode.condition0IsTrue_1 = {val:false};
gdjs.CreditCode.condition1IsTrue_1 = {val:false};
gdjs.CreditCode.condition2IsTrue_1 = {val:false};


gdjs.CreditCode.eventsList0 = function(runtimeScene) {

{


gdjs.CreditCode.condition0IsTrue_0.val = false;
gdjs.CreditCode.condition1IsTrue_0.val = false;
{
gdjs.CreditCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Tab");
}if ( gdjs.CreditCode.condition0IsTrue_0.val ) {
{
{gdjs.CreditCode.conditionTrue_1 = gdjs.CreditCode.condition1IsTrue_0;
gdjs.CreditCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11465356);
}
}}
if (gdjs.CreditCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HomeScreen", false);
}}

}


};

gdjs.CreditCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreditCode.GDplayerObjects1.length = 0;
gdjs.CreditCode.GDplayerObjects2.length = 0;
gdjs.CreditCode.GDGuide2Objects1.length = 0;
gdjs.CreditCode.GDGuide2Objects2.length = 0;
gdjs.CreditCode.GDGuide22Objects1.length = 0;
gdjs.CreditCode.GDGuide22Objects2.length = 0;
gdjs.CreditCode.GDGuide23Objects1.length = 0;
gdjs.CreditCode.GDGuide23Objects2.length = 0;
gdjs.CreditCode.GDTitleObjects1.length = 0;
gdjs.CreditCode.GDTitleObjects2.length = 0;
gdjs.CreditCode.GDgrass1Objects1.length = 0;
gdjs.CreditCode.GDgrass1Objects2.length = 0;
gdjs.CreditCode.GDgrass2Objects1.length = 0;
gdjs.CreditCode.GDgrass2Objects2.length = 0;
gdjs.CreditCode.GDgrass3Objects1.length = 0;
gdjs.CreditCode.GDgrass3Objects2.length = 0;
gdjs.CreditCode.GDgrass4Objects1.length = 0;
gdjs.CreditCode.GDgrass4Objects2.length = 0;
gdjs.CreditCode.GDassetsObjects1.length = 0;
gdjs.CreditCode.GDassetsObjects2.length = 0;
gdjs.CreditCode.GDmusicObjects1.length = 0;
gdjs.CreditCode.GDmusicObjects2.length = 0;
gdjs.CreditCode.GDmusic2Objects1.length = 0;
gdjs.CreditCode.GDmusic2Objects2.length = 0;
gdjs.CreditCode.GDboneObjects1.length = 0;
gdjs.CreditCode.GDboneObjects2.length = 0;
gdjs.CreditCode.GDskullObjects1.length = 0;
gdjs.CreditCode.GDskullObjects2.length = 0;
gdjs.CreditCode.GDinfoObjects1.length = 0;
gdjs.CreditCode.GDinfoObjects2.length = 0;
gdjs.CreditCode.GDbackObjects1.length = 0;
gdjs.CreditCode.GDbackObjects2.length = 0;

gdjs.CreditCode.eventsList0(runtimeScene);
return;

}

gdjs['CreditCode'] = gdjs.CreditCode;
